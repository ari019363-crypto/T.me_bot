# پنل تحت وب ربات چتر

این پوشه یه اپلیکیشنِ وبِ کاملاً جداست که کنارِ خودِ ربات اجرا می‌شه و مستقیماً از همون
فایل دیتابیس (`chatr_bot.db`) می‌خونه/می‌نویسه - نیازی به هماهنگیِ پیچیده با ربات نیست.

## نصب و اجرا

```bash
cd panel
pip install -r requirements.txt

export BOT_TOKEN="همون توکنی که به bot.py می‌دی"
export PANEL_SECRET_KEY="یه رشته‌ی تصادفیِ طولانی (مثلاً با: python3 -c 'import secrets; print(secrets.token_hex(32))')"
python3 app.py
```

بعدش تو مرورگر برو به: `http://<آی‌پیِ سرور>:8080`

⚠️ **حیاتی**: پوشه‌ی `panel/` باید کنارِ همون `chatr_bot.db`ای باشه که `bot.py` ساخته
(یعنی یه پوشه بالاتر از `panel/`). اگه دیتابیس جای دیگه‌ایه، مسیرش رو با
`CHATR_DB_PATH` مشخص کن.

اولین باری که پنل بالا میاد، ازت می‌خواد یه حساب مدیر برای *خودِ پنل* بسازی (کاملاً جدا
از تلگرام - فقط برای وارد شدن به این پنل استفاده می‌شه).

## اجرای دائمی روی سرور (پیشنهادی)

برای این‌که هم `bot.py` و هم `panel/app.py` همیشه روشن بمونن (حتی بعد از ریستارتِ سرور)،
بهتره هرکدوم رو با `systemd` یا `pm2` یا `supervisor` مدیریت کنی. یه نمونه‌ی ساده با
systemd:

```ini
# /etc/systemd/system/chatr-bot.service
[Unit]
Description=Chatr Telegram Bot
After=network.target

[Service]
WorkingDirectory=/path/to/project
Environment=BOT_TOKEN=xxxxx
ExecStart=/usr/bin/python3 bot.py
Restart=always

# /etc/systemd/system/chatr-panel.service
[Unit]
Description=Chatr Web Panel
After=network.target

[Service]
WorkingDirectory=/path/to/project/panel
Environment=BOT_TOKEN=xxxxx
Environment=PANEL_SECRET_KEY=xxxxx
ExecStart=/usr/bin/python3 app.py
Restart=always
```

سپس: `systemctl enable --now chatr-bot chatr-panel`

## چیزهایی که خوبه صادقانه بدونی

- **خاموش/روشنِ «بدون از دست رفتنِ دیتا»** یعنی خاموشیِ نرم: پروسه‌ی ربات همیشه زنده
  می‌مونه (پس هیچ دیتایی پاک نمی‌شه)، فقط با یه فلگ تو دیتابیس بهش می‌گیم موقتاً پیام‌ها
  رو پردازش نکنه. اگه خودِ سرور یا پروسه بخوابه/کرش کنه، پنل به‌تنهایی نمی‌تونه دوباره
  روشنش کنه؛ برای اونجور مانیتورینگ باید از ابزاری مثل systemd (`Restart=always`) کمک
  بگیری.
- **لیست اعضا**: تلگرام به هیچ رباتی اجازه نمی‌ده لیست کاملِ اعضای یه گروه رو بگیره
  (این محدودیتِ خودِ پلتفرمه). چیزی که تو تب «اعضا» می‌بینی، فقط کسانی‌ان که ربات
  پیام‌شون رو تو گروه دیده.
- **اعلامیه** مستقیماً از پنل به APIِ تلگرام وصل می‌شه (با همون `BOT_TOKEN`)، پس حتی اگه
  ربات از پنل خاموش باشه هم اعلامیه ارسال می‌شه.
- امنیت: این پنل پشتِ هیچ HTTPS یا فایروالی نیست؛ اگه رو یه سرور عمومی اجراش می‌کنی،
  حتماً پشتِ Nginx + SSL بذارش و پورتِ 8080 رو مستقیم به اینترنت باز نذار.
