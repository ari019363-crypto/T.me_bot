# -*- coding: utf-8 -*-
"""
پنل تحت وب ربات چتر
======================
اجرا:
    pip install -r requirements.txt
    export BOT_TOKEN="همون توکنی که خودِ ربات استفاده می‌کنه"
    export PANEL_SECRET_KEY="یه رشته‌ی تصادفیِ طولانی و محرمانه"
    python app.py

بعد از بالا اومدن، آدرس http://<آی‌پی‌سرور>:8080 رو باز کن. دفعه‌ی اول ازت می‌خواد یه
حساب مدیر برای خودِ پنل بسازی (این حساب کاملاً جدا از تلگرامه، فقط برای ورود به این پنله).

نکته‌ی مهم: این پنل باید کنار فایل chatr_bot.db (همون‌جایی که bot.py اجراش می‌کنی) باشه،
چون از همون دیتابیس می‌خونه/می‌نویسه. اگه جای دیگه‌ایه، مسیرش رو با متغیر محیطیِ
CHATR_DB_PATH بده.
"""
import os
import json
import shutil
import hashlib
import secrets
import urllib.request
import urllib.error
from datetime import datetime
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for, session, flash,
    jsonify, send_file, abort,
)
from werkzeug.routing import BaseConverter

import db

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BACKUP_DIR = os.path.join(BASE_DIR, "backups")

app = Flask(__name__)
app.secret_key = os.environ.get("PANEL_SECRET_KEY", secrets.token_hex(32))


class SignedIntConverter(BaseConverter):
    """آی‌دیِ گروه‌های تلگرام همیشه منفیه؛ کانورتر پیش‌فرضِ int فلسک عدد منفی رو قبول نمی‌کنه."""
    regex = r"-?\d+"

    def to_python(self, value):
        return int(value)

    def to_url(self, value):
        return str(value)


app.url_map.converters["int"] = SignedIntConverter

db.init_panel_db()
os.makedirs(BACKUP_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# کمکی‌ها
# ---------------------------------------------------------------------------
def hash_password(password: str, salt: str = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 200_000)
    return f"{salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt, _ = stored.split("$")
    except ValueError:
        return False
    return secrets.compare_digest(hash_password(password, salt), stored)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("username"):
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def send_telegram_message(chat_id: int, text: str) -> bool:
    if not BOT_TOKEN:
        return False
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = json.dumps({"chat_id": chat_id, "text": text}).encode("utf-8")
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = json.loads(resp.read().decode("utf-8"))
            return bool(body.get("ok"))
    except Exception:
        return False


def bot_online_status():
    status = db.get_bot_status()
    paused = db.get_bot_control("paused", "0") == "1"
    if not status or not status["last_heartbeat"]:
        return {"state": "unknown", "label": "هنوز از ربات خبری نرسیده", "paused": paused, "started_at": None, "last_heartbeat": None}
    last = datetime.fromisoformat(status["last_heartbeat"])
    age = (datetime.utcnow() - last).total_seconds()
    if paused:
        state, label = "paused", "خاموشِ نرم (از پنل خاموش شده)"
    elif age <= 150:
        state, label = "online", "روشن و در حال کار"
    else:
        state, label = "offline", "پروسه پاسخ نمی‌ده (احتمالاً خاموشه یا کرش کرده)"
    return {
        "state": state, "label": label, "paused": paused,
        "started_at": status["started_at"], "last_heartbeat": status["last_heartbeat"],
        "age_seconds": age,
    }


@app.template_filter("fa_dt")
def fa_dt(value):
    if not value:
        return "-"
    try:
        dt = datetime.fromisoformat(value)
        return dt.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return value


@app.template_filter("uptime_human")
def uptime_human(started_at):
    if not started_at:
        return "-"
    try:
        started = datetime.fromisoformat(started_at)
    except Exception:
        return "-"
    seconds = int((datetime.utcnow() - started).total_seconds())
    if seconds < 0:
        seconds = 0
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, _ = divmod(seconds, 60)
    parts = []
    if days:
        parts.append(f"{days} روز")
    if hours:
        parts.append(f"{hours} ساعت")
    parts.append(f"{minutes} دقیقه")
    return " و ".join(parts)


# ---------------------------------------------------------------------------
# احراز هویت
# ---------------------------------------------------------------------------
@app.route("/setup", methods=["GET", "POST"])
def setup():
    if db.count_panel_users() > 0:
        return redirect(url_for("login"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        if not username or len(password) < 6:
            flash("نام کاربری لازمه و رمز عبور باید حداقل ۶ کاراکتر باشه.", "error")
        elif password != confirm:
            flash("رمز عبور و تکرارش یکی نیستن.", "error")
        else:
            db.create_panel_user(username, hash_password(password))
            db.panel_log(username, "ساخت حساب مدیر", "اولین حساب پنل ساخته شد")
            flash("حساب ساخته شد، حالا وارد شو.", "success")
            return redirect(url_for("login"))
    return render_template("setup.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if db.count_panel_users() == 0:
        return redirect(url_for("setup"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = db.get_panel_user(username)
        if user and verify_password(password, user["password_hash"]):
            session["username"] = username
            db.panel_log(username, "ورود موفق")
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("نام کاربری یا رمز عبور اشتباهه.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    if session.get("username"):
        db.panel_log(session["username"], "خروج")
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# داشبورد
# ---------------------------------------------------------------------------
@app.route("/")
@login_required
def dashboard():
    overview = db.stats_overview()
    status = bot_online_status()
    recent_logs = db.get_mod_logs(8)
    groups = db.list_groups()
    return render_template("dashboard.html", overview=overview, status=status, recent_logs=recent_logs, groups=groups[:5], total_groups=len(groups))


# ---------------------------------------------------------------------------
# گروه‌ها
# ---------------------------------------------------------------------------
@app.route("/groups")
@login_required
def groups_list():
    groups = db.list_groups()
    return render_template("groups.html", groups=groups)


@app.route("/groups/<int:chat_id>")
@login_required
def group_detail(chat_id):
    tab = request.args.get("tab", "members")
    title = db.get_group_title(chat_id)
    settings = db.get_group_settings(chat_id)
    if settings is None:
        abort(404)
    ctx = dict(chat_id=chat_id, title=title, settings=settings, tab=tab,
               bool_fields=db.SETTINGS_BOOL_FIELDS, num_fields=db.SETTINGS_NUM_FIELDS)
    if tab == "members":
        ctx["members"] = db.get_group_members(chat_id)
        ctx["mutes"] = db.get_group_mutes(chat_id)
    elif tab == "warnings":
        ctx["warnings"] = db.get_group_warnings(chat_id)
    elif tab == "words":
        ctx["words"] = db.get_forbidden_words(chat_id)
    elif tab == "special":
        ctx["special"] = db.get_special_members(chat_id)
    return render_template("group_detail.html", **ctx)


@app.route("/groups/<int:chat_id>/setting", methods=["POST"])
@login_required
def group_setting_update(chat_id):
    field = request.form.get("field")
    value = request.form.get("value")
    try:
        if field in {f for f, _ in db.SETTINGS_BOOL_FIELDS}:
            value = 1 if value in ("1", "true", "on") else 0
        elif field in {f for f, _ in db.SETTINGS_NUM_FIELDS}:
            value = int(value)
        else:
            return jsonify({"ok": False, "error": "فیلد نامعتبر"}), 400
        db.update_group_setting(chat_id, field, value)
        db.panel_log(session["username"], "تغییر تنظیمات گروه", f"chat_id={chat_id} {field}={value}")
        return jsonify({"ok": True, "value": value})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/groups/<int:chat_id>/words/add", methods=["POST"])
@login_required
def group_word_add(chat_id):
    word = request.form.get("word", "").strip()
    if word:
        db.add_forbidden_word(chat_id, word)
        db.panel_log(session["username"], "افزودن کلمه ممنوعه", f"chat_id={chat_id} word={word}")
    return redirect(url_for("group_detail", chat_id=chat_id, tab="words"))


@app.route("/groups/<int:chat_id>/words/remove", methods=["POST"])
@login_required
def group_word_remove(chat_id):
    word = request.form.get("word", "")
    db.remove_forbidden_word(chat_id, word)
    db.panel_log(session["username"], "حذف کلمه ممنوعه", f"chat_id={chat_id} word={word}")
    return redirect(url_for("group_detail", chat_id=chat_id, tab="words"))


@app.route("/groups/<int:chat_id>/special/add", methods=["POST"])
@login_required
def group_special_add(chat_id):
    try:
        user_id = int(request.form.get("user_id", "").strip())
    except (TypeError, ValueError):
        flash("آی‌دی عددیِ کاربر رو درست وارد کن.", "error")
        return redirect(url_for("group_detail", chat_id=chat_id, tab="special"))
    db.add_special_member_panel(chat_id, user_id)
    db.panel_log(session["username"], "افزودن فرد ویژه", f"chat_id={chat_id} user_id={user_id}")
    return redirect(url_for("group_detail", chat_id=chat_id, tab="special"))


@app.route("/groups/<int:chat_id>/special/remove", methods=["POST"])
@login_required
def group_special_remove(chat_id):
    user_id = int(request.form.get("user_id"))
    db.remove_special_member_panel(chat_id, user_id)
    db.panel_log(session["username"], "حذف فرد ویژه", f"chat_id={chat_id} user_id={user_id}")
    return redirect(url_for("group_detail", chat_id=chat_id, tab="special"))


@app.route("/groups/<int:chat_id>/warnings/<int:user_id>/clear", methods=["POST"])
@login_required
def group_warning_clear(chat_id, user_id):
    db.clear_group_warning(chat_id, user_id)
    db.panel_log(session["username"], "پاک‌کردن اخطارها", f"chat_id={chat_id} user_id={user_id}")
    return redirect(url_for("group_detail", chat_id=chat_id, tab="warnings"))


@app.route("/groups/<int:chat_id>/mutes/<int:user_id>/remove", methods=["POST"])
@login_required
def group_mute_remove(chat_id, user_id):
    db.unmute_panel(chat_id, user_id)
    db.panel_log(session["username"], "حذف از لیست سکوت", f"chat_id={chat_id} user_id={user_id}")
    flash("از لیست پاک شد. برای آزادسازیِ واقعیِ کاربر تو تلگرام (اگه هنوز سکوته)، داخل خودِ گروه روی پیامش ریپلای بزن و بنویس «آزاد».", "info")
    return redirect(url_for("group_detail", chat_id=chat_id, tab="members"))


# ---------------------------------------------------------------------------
# بازی دوز
# ---------------------------------------------------------------------------
@app.route("/dooz")
@login_required
def dooz_page():
    leaderboard = db.dooz_leaderboard()
    recent = db.dooz_recent_games()
    totals = db.dooz_totals()
    return render_template("dooz.html", leaderboard=leaderboard, recent=recent, totals=totals)


# ---------------------------------------------------------------------------
# حافظه
# ---------------------------------------------------------------------------
@app.route("/memory")
@login_required
def memory_page():
    q = request.args.get("q", "").strip()
    notes = db.get_memory_notes(q=q)
    return render_template("memory.html", notes=notes, q=q)


@app.route("/memory/<int:note_id>/delete", methods=["POST"])
@login_required
def memory_delete(note_id):
    db.delete_memory_note(note_id)
    db.panel_log(session["username"], "حذف حافظه", f"note_id={note_id}")
    return redirect(url_for("memory_page"))


# ---------------------------------------------------------------------------
# آمار
# ---------------------------------------------------------------------------
@app.route("/stats")
@login_required
def stats_page():
    overview = db.stats_overview()
    groups = db.list_groups()
    return render_template("stats.html", overview=overview, groups=groups)


# ---------------------------------------------------------------------------
# لاگ
# ---------------------------------------------------------------------------
@app.route("/logs")
@login_required
def logs_page():
    mod_logs = db.get_mod_logs(150)
    panel_logs = db.get_panel_logs(150)
    return render_template("logs.html", mod_logs=mod_logs, panel_logs=panel_logs)


# ---------------------------------------------------------------------------
# بکاپ
# ---------------------------------------------------------------------------
@app.route("/backup")
@login_required
def backup_page():
    files = sorted(os.listdir(BACKUP_DIR), reverse=True) if os.path.isdir(BACKUP_DIR) else []
    return render_template("backup.html", files=files, db_path=db.DB_PATH)


@app.route("/backup/create", methods=["POST"])
@login_required
def backup_create():
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    dest = os.path.join(BACKUP_DIR, f"chatr_bot_{ts}.db")
    shutil.copyfile(db.DB_PATH, dest)
    db.panel_log(session["username"], "گرفتن بکاپ", dest)
    flash("بکاپ گرفته شد ✅", "success")
    return redirect(url_for("backup_page"))


@app.route("/backup/download/<path:filename>")
@login_required
def backup_download(filename):
    path = os.path.join(BACKUP_DIR, filename)
    if not os.path.isfile(path):
        abort(404)
    return send_file(path, as_attachment=True)


# ---------------------------------------------------------------------------
# وضعیت ربات
# ---------------------------------------------------------------------------
@app.route("/bot-status")
@login_required
def bot_status_page():
    status = bot_online_status()
    overview = db.stats_overview()
    return render_template("bot_status.html", status=status, overview=overview)


@app.route("/bot-status/toggle", methods=["POST"])
@login_required
def bot_status_toggle():
    action = request.form.get("action")
    if action == "pause":
        db.set_bot_control("paused", "1")
        db.panel_log(session["username"], "خاموش کردن ربات (نرم)")
        flash("ربات خاموشِ نرم شد؛ پروسه زنده می‌مونه، هیچ دیتایی از دست نمی‌ره، فقط پیام‌ها پردازش نمی‌شن.", "success")
    elif action == "resume":
        db.set_bot_control("paused", "0")
        db.panel_log(session["username"], "روشن کردن دوباره ربات")
        flash("ربات دوباره روشن شد ✅", "success")
    return redirect(url_for("bot_status_page"))


# ---------------------------------------------------------------------------
# تنظیمات کلی (رمز پنل + اعلامیه)
# ---------------------------------------------------------------------------
@app.route("/settings")
@login_required
def settings_page():
    broadcasts = db.get_broadcasts(10)
    return render_template("settings.html", broadcasts=broadcasts, groups_count=db.count_groups())


@app.route("/settings/password", methods=["POST"])
@login_required
def settings_password():
    current = request.form.get("current_password", "")
    new = request.form.get("new_password", "")
    confirm = request.form.get("confirm_password", "")
    user = db.get_panel_user(session["username"])
    if not verify_password(current, user["password_hash"]):
        flash("رمز فعلی اشتباهه.", "error")
    elif len(new) < 6:
        flash("رمز جدید باید حداقل ۶ کاراکتر باشه.", "error")
    elif new != confirm:
        flash("رمز جدید و تکرارش یکی نیستن.", "error")
    else:
        db.update_panel_password(session["username"], hash_password(new))
        db.panel_log(session["username"], "تغییر رمز پنل")
        flash("رمز عبور عوض شد ✅", "success")
    return redirect(url_for("settings_page"))


@app.route("/settings/broadcast", methods=["POST"])
@login_required
def settings_broadcast():
    message = request.form.get("message", "").strip()
    if not message:
        flash("متن اعلامیه خالیه.", "error")
        return redirect(url_for("settings_page"))
    if not BOT_TOKEN:
        flash("متغیر محیطیِ BOT_TOKEN تنظیم نشده، پس پنل نمی‌تونه مستقیم به تلگرام پیام بده.", "error")
        return redirect(url_for("settings_page"))
    chat_ids = db.all_group_chat_ids()
    success, fail = 0, 0
    for cid in chat_ids:
        if send_telegram_message(cid, message):
            success += 1
        else:
            fail += 1
    db.record_broadcast(message, session["username"], len(chat_ids), success, fail)
    db.panel_log(session["username"], "ارسال اعلامیه", f"{success}/{len(chat_ids)} موفق")
    flash(f"اعلامیه به {success} گروه از {len(chat_ids)} گروه ارسال شد.", "success" if fail == 0 else "info")
    return redirect(url_for("settings_page"))


if __name__ == "__main__":
    port = int(os.environ.get("PORT", os.environ.get("PANEL_PORT", "8080")))
    app.run(host="0.0.0.0", port=port, debug=False)
