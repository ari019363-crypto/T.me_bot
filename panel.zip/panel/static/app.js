// سوییچ‌های تنظیمات: با هر تغییر، بدون رفرشِ صفحه به سرور خبر می‌ده
document.addEventListener("change", async (e) => {
  const el = e.target;
  if (!el.matches("[data-toggle-url]")) return;
  const url = el.getAttribute("data-toggle-url");
  const field = el.getAttribute("data-field");
  const value = el.checked ? "1" : "0";
  const row = el.closest(".setting-row");
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `field=${encodeURIComponent(field)}&value=${value}`,
    });
    const data = await res.json();
    if (!data.ok) {
      el.checked = !el.checked;
      alert("مشکلی پیش اومد: " + (data.error || "نامشخص"));
    } else if (row) {
      row.classList.add("saved-flash");
      setTimeout(() => row.classList.remove("saved-flash"), 500);
    }
  } catch (err) {
    el.checked = !el.checked;
    alert("ارتباط با سرور برقرار نشد.");
  }
});

document.addEventListener("change", async (e) => {
  const el = e.target;
  if (!el.matches("[data-number-url]")) return;
  const url = el.getAttribute("data-number-url");
  const field = el.getAttribute("data-field");
  const value = el.value;
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `field=${encodeURIComponent(field)}&value=${encodeURIComponent(value)}`,
    });
    const data = await res.json();
    if (!data.ok) alert("مشکلی پیش اومد: " + (data.error || "نامشخص"));
  } catch (err) {
    alert("ارتباط با سرور برقرار نشد.");
  }
});
