# -*- coding: utf-8 -*-
"""
لایه‌ی دیتابیسِ پنل وب.
همون فایل chatr_bot.db که کنار bot.py ساخته می‌شه رو باز می‌کنه (WAL فعاله، پس هم‌زمان با
ربات هم قابل خوندن/نوشتنه، بدون قفل‌شدن). این ماژول فقط جدول‌هایی که خودِ پنل بهشون نیاز داره
رو می‌سازه (panel_users, panel_logs, broadcasts) - بقیه‌ی جدول‌ها (group_settings, warnings, ...)
همونایی هستن که bot.py می‌سازه؛ پنل فقط ازشون می‌خونه/می‌نویسه.
"""
import os
import json
import sqlite3
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.environ.get("CHATR_DB_PATH", os.path.join(BASE_DIR, "chatr_bot.db"))


def get_conn():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=8000")
    return conn


SETTINGS_BOOL_FIELDS = [
    ("locked", "قفل گروه (فقط ادمین‌ها پیام بدن)"),
    ("forward_allowed", "اجازه‌ی فوروارد"),
    ("block_links", "مسدودسازی لینک"),
    ("spam_protection", "ضداسپم"),
    ("allow_photo", "اجازه‌ی عکس"),
    ("allow_video", "اجازه‌ی ویدیو"),
    ("allow_sticker_gif", "اجازه‌ی استیکر/گیف"),
    ("use_default_pack", "استفاده از پک کلمات پیش‌فرض"),
    ("welcome_messages_enabled", "پیام خوش‌آمد/خداحافظ"),
    ("engagement_enabled", "پیام‌های تعاملیِ خودکار"),
    ("admin_actions_on_owner", "اعمال قابلیت‌های ادمین روی مالک"),
]
SETTINGS_NUM_FIELDS = [
    ("spam_threshold", "آستانه‌ی اسپم (تعداد پیام پشت‌سرهم)"),
    ("spam_mute_minutes", "مدت سکوتِ اسپم (دقیقه)"),
    ("engagement_interval_hours", "فاصله‌ی پیام‌های تعاملی (ساعت)"),
]


# ---------------------------------------------------------------------------
# راه‌اندازی جدول‌های مخصوص پنل
# ---------------------------------------------------------------------------
def init_panel_db():
    conn = get_conn()
    c = conn.cursor()
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS panel_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT
        );

        CREATE TABLE IF NOT EXISTS panel_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT,
            action TEXT,
            details TEXT,
            created_at TEXT
        );

        CREATE TABLE IF NOT EXISTS broadcasts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT,
            sent_by TEXT,
            total_groups INTEGER,
            success_count INTEGER,
            fail_count INTEGER,
            created_at TEXT
        );

        CREATE TABLE IF NOT EXISTS bot_control (
            key TEXT PRIMARY KEY,
            value TEXT
        );

        CREATE TABLE IF NOT EXISTS bot_status (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            started_at TEXT,
            last_heartbeat TEXT
        );

        CREATE TABLE IF NOT EXISTS mod_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER,
            actor_id INTEGER,
            actor_name TEXT,
            action TEXT,
            target_id INTEGER,
            target_name TEXT,
            reason TEXT,
            created_at TEXT
        );
        """
    )
    c.execute("INSERT OR IGNORE INTO bot_control (key, value) VALUES ('paused', '0')")
    conn.commit()
    conn.close()


def panel_log(actor: str, action: str, details: str = ""):
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO panel_logs (actor, action, details, created_at) VALUES (?, ?, ?, ?)",
        (actor, action, details, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# کاربران پنل (لاگین)
# ---------------------------------------------------------------------------
def get_panel_user(username: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM panel_users WHERE username=?", (username,))
    row = c.fetchone()
    conn.close()
    return row


def count_panel_users() -> int:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) AS n FROM panel_users")
    n = c.fetchone()["n"]
    conn.close()
    return n


def create_panel_user(username: str, password_hash: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO panel_users (username, password_hash, created_at) VALUES (?, ?, ?)",
        (username, password_hash, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


def update_panel_password(username: str, password_hash: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("UPDATE panel_users SET password_hash=? WHERE username=?", (password_hash, username))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# داشبورد / وضعیت ربات
# ---------------------------------------------------------------------------
def get_bot_control(key: str, default=None):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT value FROM bot_control WHERE key=?", (key,))
    row = c.fetchone()
    conn.close()
    return row["value"] if row else default


def set_bot_control(key: str, value: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO bot_control (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value),
    )
    conn.commit()
    conn.close()


def get_bot_status():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM bot_status WHERE id=1")
    row = c.fetchone()
    conn.close()
    return row


def count_groups() -> int:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) AS n FROM group_settings")
    n = c.fetchone()["n"]
    conn.close()
    return n


def count_total_members() -> int:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) AS n FROM group_members WHERE is_present=1")
    n = c.fetchone()["n"]
    conn.close()
    return n


def count_row(table: str) -> int:
    conn = get_conn()
    c = conn.cursor()
    try:
        c.execute(f"SELECT COUNT(*) AS n FROM {table}")
        n = c.fetchone()["n"]
    except sqlite3.OperationalError:
        n = 0
    conn.close()
    return n


# ---------------------------------------------------------------------------
# گروه‌ها
# ---------------------------------------------------------------------------
def list_groups():
    """لیست همه‌ی گروه‌هایی که ربات توشونه، با عنوان (از user_groups) و تعداد عضوِ دیده‌شده."""
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT chat_id, owner_user_id, locked, spam_protection FROM group_settings ORDER BY chat_id")
    rows = c.fetchall()
    result = []
    for r in rows:
        chat_id = r["chat_id"]
        c.execute("SELECT title FROM user_groups WHERE chat_id=? AND title IS NOT NULL LIMIT 1", (chat_id,))
        t = c.fetchone()
        title = t["title"] if t else f"گروه {chat_id}"
        c.execute("SELECT COUNT(*) AS n FROM group_members WHERE chat_id=? AND is_present=1", (chat_id,))
        member_count = c.fetchone()["n"]
        c.execute("SELECT COUNT(*) AS n FROM warnings WHERE chat_id=?", (chat_id,))
        warn_count = c.fetchone()["n"]
        c.execute("SELECT COUNT(*) AS n FROM mutes WHERE chat_id=?", (chat_id,))
        mute_count = c.fetchone()["n"]
        result.append(
            {
                "chat_id": chat_id,
                "title": title,
                "member_count": member_count,
                "warn_count": warn_count,
                "mute_count": mute_count,
                "locked": bool(r["locked"]),
                "spam_protection": bool(r["spam_protection"]),
            }
        )
    conn.close()
    return result


def get_group_title(chat_id: int) -> str:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT title FROM user_groups WHERE chat_id=? AND title IS NOT NULL LIMIT 1", (chat_id,))
    row = c.fetchone()
    conn.close()
    return row["title"] if row else f"گروه {chat_id}"


def get_group_settings(chat_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM group_settings WHERE chat_id=?", (chat_id,))
    row = c.fetchone()
    conn.close()
    return row


def update_group_setting(chat_id: int, field: str, value):
    allowed = {f for f, _ in SETTINGS_BOOL_FIELDS} | {f for f, _ in SETTINGS_NUM_FIELDS}
    if field not in allowed:
        raise ValueError("فیلد مجاز نیست")
    conn = get_conn()
    c = conn.cursor()
    c.execute(f"UPDATE group_settings SET {field}=? WHERE chat_id=?", (value, chat_id))
    conn.commit()
    conn.close()


def get_group_members(chat_id: int, only_present: bool = True, limit: int = 500):
    conn = get_conn()
    c = conn.cursor()
    q = "SELECT * FROM group_members WHERE chat_id=?"
    if only_present:
        q += " AND is_present=1"
    q += " ORDER BY updated_at DESC LIMIT ?"
    c.execute(q, (chat_id, limit))
    rows = c.fetchall()
    conn.close()
    return rows


def get_group_warnings(chat_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM warnings WHERE chat_id=? AND count > 0 ORDER BY count DESC", (chat_id,))
    rows = c.fetchall()
    out = []
    for r in rows:
        try:
            reasons = json.loads(r["reasons"])
        except Exception:
            reasons = []
        m = get_member_name(chat_id, r["user_id"])
        out.append({"user_id": r["user_id"], "name": m, "count": r["count"], "reasons": reasons})
    conn.close()
    return out


def clear_group_warning(chat_id: int, user_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM warnings WHERE chat_id=? AND user_id=?", (chat_id, user_id))
    conn.commit()
    conn.close()


def get_member_name(chat_id: int, user_id: int) -> str:
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT first_name, username FROM group_members WHERE chat_id=? AND user_id=?", (chat_id, user_id))
    row = c.fetchone()
    conn.close()
    if row:
        return row["first_name"] or (f"@{row['username']}" if row["username"] else str(user_id))
    return str(user_id)


def get_forbidden_words(chat_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT word FROM forbidden_words WHERE chat_id=? ORDER BY word", (chat_id,))
    rows = [r["word"] for r in c.fetchall()]
    conn.close()
    return rows


def add_forbidden_word(chat_id: int, word: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO forbidden_words (chat_id, word) VALUES (?, ?)", (chat_id, word.strip()))
    conn.commit()
    conn.close()


def remove_forbidden_word(chat_id: int, word: str):
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM forbidden_words WHERE chat_id=? AND word=?", (chat_id, word))
    conn.commit()
    conn.close()


def get_special_members(chat_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT user_id, custom_tone FROM special_members WHERE chat_id=?", (chat_id,))
    rows = c.fetchall()
    out = [{"user_id": r["user_id"], "custom_tone": r["custom_tone"], "name": get_member_name(chat_id, r["user_id"])} for r in rows]
    conn.close()
    return out


def add_special_member_panel(chat_id: int, user_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO special_members (chat_id, user_id) VALUES (?, ?)", (chat_id, user_id))
    conn.commit()
    conn.close()


def remove_special_member_panel(chat_id: int, user_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM special_members WHERE chat_id=? AND user_id=?", (chat_id, user_id))
    conn.commit()
    conn.close()


def get_group_mutes(chat_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM mutes WHERE chat_id=? ORDER BY until_ts IS NULL DESC, until_ts ASC", (chat_id,))
    rows = c.fetchall()
    conn.close()
    return rows


def unmute_panel(chat_id: int, user_id: int):
    """فقط رکورد رو از دیتابیس پاک می‌کنه؛ اگه ربات روشن باشه، خودش با دیدنِ همین حذف هم‌زمان
    نیست - برای آزادسازیِ واقعیِ کاربر تو تلگرام، از دستورِ «آزاد» داخل خودِ گروه استفاده کن.
    (این محدودیت به این خاطره که فقط پروسه‌ی زنده‌ی ربات به توکن و APIِ تلگرام دسترسی داره.)"""
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM mutes WHERE chat_id=? AND user_id=?", (chat_id, user_id))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# بازی دوز
# ---------------------------------------------------------------------------
def dooz_leaderboard(limit: int = 50):
    conn = get_conn()
    c = conn.cursor()
    try:
        c.execute(
            "SELECT * FROM dooz_player_stats ORDER BY wins DESC, total_games DESC LIMIT ?", (limit,)
        )
        rows = c.fetchall()
    except sqlite3.OperationalError:
        rows = []
    conn.close()
    return rows


def dooz_recent_games(limit: int = 30):
    conn = get_conn()
    c = conn.cursor()
    try:
        c.execute("SELECT * FROM dooz_games ORDER BY game_id DESC LIMIT ?", (limit,))
        rows = c.fetchall()
    except sqlite3.OperationalError:
        rows = []
    conn.close()
    return rows


def dooz_totals():
    conn = get_conn()
    c = conn.cursor()
    out = {"total_games": 0, "active_games": 0, "total_players": 0}
    try:
        c.execute("SELECT COUNT(*) AS n FROM dooz_games")
        out["total_games"] = c.fetchone()["n"]
        c.execute("SELECT COUNT(*) AS n FROM dooz_games WHERE status='active'")
        out["active_games"] = c.fetchone()["n"]
        c.execute("SELECT COUNT(*) AS n FROM dooz_player_stats")
        out["total_players"] = c.fetchone()["n"]
    except sqlite3.OperationalError:
        pass
    conn.close()
    return out


# ---------------------------------------------------------------------------
# حافظه (koliba_memory)
# ---------------------------------------------------------------------------
def get_memory_notes(chat_id=None, q: str = "", limit: int = 200):
    conn = get_conn()
    c = conn.cursor()
    query = "SELECT * FROM koliba_memory WHERE 1=1"
    params = []
    if chat_id:
        query += " AND chat_id=?"
        params.append(chat_id)
    if q:
        query += " AND (note_text LIKE ? OR user_name LIKE ?)"
        params.extend([f"%{q}%", f"%{q}%"])
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    c.execute(query, params)
    rows = c.fetchall()
    conn.close()
    return rows


def delete_memory_note(note_id: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute("DELETE FROM koliba_memory WHERE id=?", (note_id,))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# لاگ (مدیریتی + پنل)
# ---------------------------------------------------------------------------
def get_mod_logs(limit: int = 100):
    conn = get_conn()
    c = conn.cursor()
    try:
        c.execute("SELECT * FROM mod_logs ORDER BY id DESC LIMIT ?", (limit,))
        rows = c.fetchall()
    except sqlite3.OperationalError:
        rows = []
    conn.close()
    return rows


def get_panel_logs(limit: int = 100):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM panel_logs ORDER BY id DESC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return rows


# ---------------------------------------------------------------------------
# اعلامیه (پیام همگانی به تمام گروه‌ها)
# ---------------------------------------------------------------------------
def all_group_chat_ids():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT chat_id FROM group_settings")
    ids = [r["chat_id"] for r in c.fetchall()]
    conn.close()
    return ids


def record_broadcast(message: str, sent_by: str, total: int, success: int, fail: int):
    conn = get_conn()
    c = conn.cursor()
    c.execute(
        "INSERT INTO broadcasts (message, sent_by, total_groups, success_count, fail_count, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (message, sent_by, total, success, fail, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


def get_broadcasts(limit: int = 30):
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM broadcasts ORDER BY id DESC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return rows


# ---------------------------------------------------------------------------
# آمار
# ---------------------------------------------------------------------------
def stats_overview():
    return {
        "groups": count_groups(),
        "members": count_total_members(),
        "warnings": count_row("warnings"),
        "forbidden_words": count_row("forbidden_words"),
        "special_members": count_row("special_members"),
        "active_mutes": count_row("mutes"),
        "memory_notes": count_row("koliba_memory"),
        "dooz": dooz_totals(),
    }
